﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllieBeckman_8._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void countButton_Click(object sender, EventArgs e)
        {
            // get the users string each time the button is pressed
            string userInput = userTextBox.Text;
            // default number of words is 0 if theres nothing
            int numberOfWords = 0;

            // call my word counting class method with the users input
            countTheWords userWordsToCount = new countTheWords(userInput);

            // use the method to return the number of words
            numberOfWords = userWordsToCount.getWords();

            // print the number of words on the desplay screen
            wordCountLabel.Text = numberOfWords.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    // class with a count word method and a return variable method
    public class countTheWords
    {
        // variable to hold number of words
        public int words = 0;

        // a method to count words in a string
        public countTheWords(string userInput)
        {
            /**
             * I was trying to use this to count each word but for some
             * reason it was only counting the number of spaces?? 
             * I thought I'd leave it in here incase you had time to 
             * help me puzzle it out.
             * My working code is below this comment block :)
             * 
             int i = 0;
             int length = userInput.Length;
             while (i < length)
             {
                 // counts letters
                 if (i < length && !char.IsWhiteSpace(userInput[i]))
                 {
                     i++;
                     
                 }
                 
                 // counts white spaces
                 while (i < length && char.IsWhiteSpace(userInput[i]))
                 {
                     i++;

                     if (i < length && !char.IsWhiteSpace(userInput[i]))
                     {
                         i++;
                         words++;
                     }
            }
            **/

            // regix method to count words while ignoring special characters
            var matchesByListedChars = Regex.Matches(userInput,
            @"[^\s.?,]+", RegexOptions.CultureInvariant | RegexOptions.Multiline
            | RegexOptions.IgnoreCase);

            words = matchesByListedChars.Count;

        }
        

        // a method to retreve the counted number of words
        public int getWords()
        {
            return words;
        }
    }
}


