﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllieBeckman_8._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void countButton_Click(object sender, EventArgs e)
        {
            // get the users string each time the button is pressed
            string userInput = userTextBox.Text;

            // default number of words and letters is 0 if theres nothing
            int numberOfWords = 0;
            int numberOfLetters = 0;

            // call my word counting class method with the users input
            // use the method to return the number of words
            // print the number of words on the desplay screen
            countTheWords userWordsToCount = new countTheWords(userInput);
            numberOfWords = userWordsToCount.getWords(); 
            wordCountLabel.Text = numberOfWords.ToString();

            // call letter counting class method using user input
            // use the get letter method in that class
            // print the number of letters to string
            countTheLetters userLettersToCount = new countTheLetters(userInput);
            numberOfLetters = userLettersToCount.getLetters();
            letterCountLabel.Text = numberOfLetters.ToString();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    // class with a count word method and a return variable method
    public class countTheWords
    {
        // variable to hold number of words
        public int words = 0;

        // a method to count words in a string
        public countTheWords(string userInput)
        {
            /**
             * I was trying to use this to count each word but for some
             * reason it was only counting the number of spaces?? 
             * I thought I'd leave it in here incase you had time to 
             * help me puzzle it out.
             * My working code is below this comment block :)
             * 
             * (edit) - Just realized I can use this for the next programming problem.
             * 
             int i = 0;
             int length = userInput.Length;
             while (i < length)
             {
                 // counts letters
                 if (i < length && !char.IsWhiteSpace(userInput[i]))
                 {
                     i++;
                     
                 }
                 
                 // counts white spaces
                 while (i < length && char.IsWhiteSpace(userInput[i]))
                 {
                     i++;

                     if (i < length && !char.IsWhiteSpace(userInput[i]))
                     {
                         i++;
                         words++;
                     }
            }
            **/

            // regix method to count words while ignoring special characters
            var matchesByListedChars = Regex.Matches(userInput,
            @"[^\s.?,]+", RegexOptions.CultureInvariant | RegexOptions.Multiline
            | RegexOptions.IgnoreCase);

            words = matchesByListedChars.Count;

        }
        

        // a method to retreve the counted number of words
        public int getWords()
        {
            return words;
        }
    }

    // a class holding the methods to count the letters of the string.
    public class countTheLetters
    {
        // variable for the number of letters to be returned
        public int letters;

        // method accepting a string
        public countTheLetters(string userInput)
        {
            // a counter variable and the length of the string
            int i = 0;
            int length = userInput.Length;


            while (i < length)
            {
                // counts letters
                while (i < length && !char.IsWhiteSpace(userInput[i]))
                {
                    i++;
                    letters++;
                }

                // counts white spaces
                while (i < length && char.IsWhiteSpace(userInput[i]))
                {
                    i++;
                }
            }
        }

        // return letter count
        public int getLetters()
        {
            return letters;
        }
    }
}


