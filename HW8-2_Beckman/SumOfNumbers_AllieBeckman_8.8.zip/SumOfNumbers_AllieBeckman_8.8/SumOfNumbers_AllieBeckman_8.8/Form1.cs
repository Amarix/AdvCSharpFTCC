﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SumOfNumbers_AllieBeckman_8._8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            string finalSum;

            // get the users text
            string usersNumbers = userInputTextBox.Text;

            // call the method
            addNumbers add = new addNumbers(usersNumbers);

            // retreve the added numbers to a string
            finalSum = add.getSumOfNumbers();

            // post the sum to the label
            sumLabel.Text = finalSum;
        }
    }
    // class and method to accept users input and seperate numbers
    // then add numbers
    public class addNumbers
    {
        int sum;

        public addNumbers(string userInput)
        {
            // make a string array of the seperated numbers
            string[] numbersInString = userInput.Split(',');

            // a list of the numbers from this array to be added together
            List<int> numbers = new List<int>();

            int i = 0; // counter

            // sort through the array
            while (i <= numbersInString.Length)
            {
                try
                {
                    // add the string at index to a string to be 
                    // turned into an int then added to a new array of ints.
                    string currentString = numbersInString[i];

                    // change the number from a string to an int
                    int currentNumber = int.Parse(currentString);

                    // add the new int to the list
                    numbers.Add(currentNumber);

                }catch (Exception e)
                {
                }
                i++;
            }
            // add all the numbers together
            sum = numbers.Sum();
        }

        public string getSumOfNumbers()
        {
            // convert the sum to a string
            string sumOfNumbers = sum.ToString();
            // return it to main method
            return sumOfNumbers;
        }
    }
}
