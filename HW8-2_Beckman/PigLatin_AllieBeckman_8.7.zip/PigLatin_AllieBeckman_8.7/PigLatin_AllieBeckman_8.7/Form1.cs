﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PigLatin_AllieBeckman_8._7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void translateButton_Click(object sender, EventArgs e)
        {
            // take the origonal text
            string userInput = origonalTextBox.Text;

            // send the argument to the method
            translate input = new translate(userInput);

            // set the new translation to a string
            string translatedText = input.setTranslation();

            // print the translation to the label
            trainslationLabel.Text = translatedText;
        }
    }

    // a class with a method that moves the first letter
    // of each word moves it to the end of the word and adds
    // ay at the end of that.
    public class translate
    {
        // string for the final translation
        string translation;

        public translate(string userInput)
        {
            // creates an array of the words in a sentence
            string[] uInput = userInput.Split(',',' ','!','*','?','#','.','$');

            // a string of the word being changed
            string currentWord;

            int i = 0; // a counter variable

            // makes sure we aren't looking for more words than are there
            while (i <= uInput.Length){

                // a try catch to handle an exception of the array being out of range
                try
                {
                    // sets the word at the index i to the string
                    currentWord = uInput[i];

                    // find the char at the first letter
                    char splitWordAt = currentWord[0];

                    // set the first letter to a string
                    string fstLtr = splitWordAt.ToString();

                    // take whats left of the word minus the first word
                    string middle = currentWord.Trim(splitWordAt);

                    // append the first letter to the end of the rest of the word and include ay
                    string finalTranslation = string.Concat(middle, fstLtr, "ay");

                    // replace the old word in the array with the new one
                    uInput[i] = finalTranslation;
                }catch(IndexOutOfRangeException e)
                {

                }
                // counts up to the next word
                i++;
            }
            // connect all the words in the array with a " " in between each one
            translation = string.Join(" ", uInput);
        }

        public string setTranslation()
        {
            // method to return the final translation
            return translation;
        }
    }
}
